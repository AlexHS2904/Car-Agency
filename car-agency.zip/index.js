// index.js
import express from "express";
import session from "express-session";
import path from "path";
import { fileURLToPath } from "url";

import pool from "./db.js";
import adminRoutes from "./routes/admin.js";
import reservationsRoutes from "./routes/reservations.js";
import autosRoutes from "./routes/autos.js";

const app = express();

// __dirname en ESModules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 1) EJS
app.set("view engine", "ejs");
app.set("views", path.join(process.cwd(), "views"));

// 2) Middlewares
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), "public")));

app.use(
  session({
    secret: "super-secreto",
    resave: false,
    saveUninitialized: false,
  })
);

// 3) Usuario disponible en las vistas
app.use((req, res, next) => {
  res.locals.currentUser = req.session.user || null;
  next();
});

// en app.js, después de configurar views/sessions/etc.
app.locals.whatsAppPhone = process.env.WHATSAPP_PHONE || "2213987353";
app.locals.waText = encodeURIComponent("Hola, me gustaría cotizar un auto. ¿Puedes ayudarme?");
app.use((req, res, next) => {
  res.locals.currentPath = req.path || "";
  next();
});


// --- helpers de seguridad ---
function ensureLogged(req, res, next) {
  if (!req.session.user) {
    return res.redirect("/login");
  }
  next();
}

function ensureAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin") {
    return res.status(403).send("No tienes permiso");
  }
  next();
}

/* =========================
        RUTAS PÚBLICAS
   ========================= */

// HOME
app.get("/", async (req, res) => {
  try {
    const [miniCars] = await pool.query(
      `SELECT
         id,
         brand,
         model,
         year,
         price_per_day,
         image_url,
         body_type,
         seats
       FROM cars
       WHERE status IN ('available','publicado')
       ORDER BY RAND()
       LIMIT 13`
    );

    const whatsAppPhone = process.env.WHATSAPP_PHONE || "2213987353";
    const waText = encodeURIComponent("Hola, me gustaría cotizar un auto. ¿Puedes ayudarme?");

    res.render("index", { miniCars, whatsAppPhone, waText });
  } catch (err) {
    console.error("Error cargando mini carrusel:", err);

    const whatsAppPhone = process.env.WHATSAPP_PHONE || "2213987353";
    const waText = encodeURIComponent("Hola, me gustaría cotizar un auto. ¿Puedes ayudarme?");

    res.render("index", { miniCars: [], whatsAppPhone, waText });
  }
});


// LOGIN (GET)
app.get("/login", (req, res) => {
  const returnTo = req.query.returnTo || "";
  res.render("login", { error: null, returnTo });
});

// LOGIN (POST)
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const returnTo = req.body.returnTo;

  try {
    const [rows] = await pool.query(
      `SELECT u.id, u.email, u.password, r.name AS role
       FROM users u
       JOIN roles r ON u.role_id = r.id
       WHERE u.email = ?`,
      [email]
    );

    if (rows.length === 0) {
      return res
        .status(401)
        .render("login", { error: "Usuario o contraseña incorrectos", returnTo });
    }

    const user = rows[0];

    if (user.password !== password) {
      return res
        .status(401)
        .render("login", { error: "Usuario o contraseña incorrectos", returnTo });
    }

    req.session.user = {
      id: user.id,
      email: user.email,
      role: user.role,
    };

    if (returnTo && returnTo.trim() !== "") {
      return res.redirect(returnTo);
    }

    if (user.role === "admin") {
      return res.redirect("/admin/dashboard");
    } else {
      return res.redirect("/");
    }
  } catch (err) {
    console.error("Error en login:", err);
    return res.status(500).render("login", {
      error: "Error en el servidor",
      returnTo,
    });
  }
});

// REGISTER (GET)
app.get("/register", (req, res) => {
  res.render("register", { error: null });
});

// REGISTER (POST)
app.post("/register", async (req, res) => {
  const { name, email, phone, password, confirmPassword } = req.body;
  const formData = { name, email, phone };

  if (!name || !email || !password || !confirmPassword) {
    return res.status(400).render("register", {
      error: "Todos los campos obligatorios deben llenarse.",
      formData,
    });
  }

  if (password !== confirmPassword) {
    return res.status(400).render("register", {
      error: "Las contraseñas no coinciden",
      formData,
    });
  }

  try {
    const [byEmail] = await pool.query(
      "SELECT id FROM users WHERE email = ?",
      [email]
    );
    if (byEmail.length > 0) {
      return res.status(400).render("register", {
        error: "Ya existe una cuenta con ese correo.",
        formData,
      });
    }

    const [byName] = await pool.query(
      "SELECT id FROM users WHERE name = ?",
      [name]
    );
    if (byName.length > 0) {
      return res.status(400).render("register", {
        error: "Ese nombre ya está en uso.",
        formData,
      });
    }

    const [result] = await pool.query(
      "INSERT INTO users (name, email, phone, password, role_id) VALUES (?, ?, ?, ?, ?)",
      [name, email, phone || null, password, 2]
    );

    req.session.user = {
      id: result.insertId,
      email,
      role: "user",
      name,
    };

    return res.redirect("/");
  } catch (err) {
    console.error("Error en register:", err);
    return res.status(500).render("register", {
      error: "Error al registrar. Intenta de nuevo.",
      formData,
    });
  }
});

// CATÁLOGO
app.get("/catalogo", async (req, res) => {
  const { year, tipo, max_price } = req.query;

  let query = "SELECT * FROM cars WHERE status IN ('available','publicado')";
  const params = [];

  if (year && year !== "") {
    query += " AND year = ?";
    params.push(year);
  }

  if (tipo && tipo !== "") {
    query += " AND body_type = ?";
    params.push(tipo);
  }

  if (max_price && max_price !== "") {
    query += " AND price_per_day <= ?";
    params.push(max_price);
  }

  query += " ORDER BY price_per_day ASC";

  try {
    const [cars] = await pool.query(query, params);
    return res.render("catalogo", {
      cars,
      filters: { year, tipo, max_price },
    });
  } catch (err) {
    console.error("Error cargando catálogo:", err);
    return res.render("catalogo", {
      cars: [],
      filters: { year, tipo, max_price },
    });
  }
});

// CERRAR SESIÓN
app.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

/* =========================
   RUTAS PROTEGIDAS / MODULARES
   ========================= */

// 1) primero reservas para que /mis_reservas no lo pisen otras rutas
app.use("/", reservationsRoutes);

// 2) luego autos
app.use("/", autosRoutes);

// 3) admin con su prefijo
app.use("/admin", ensureAdmin, adminRoutes);

// ADMIN directo
app.get("/admin", ensureAdmin, (req, res) => {
  return res.redirect("/admin/dashboard");
});

// levantar server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("Server on " + PORT);
});
